from django.contrib import admin
from app.models import Recipe

admin.site.register(Recipe)

